<?php

namespace App\Http\Controllers;

use App\Models\ViewStatistic;
use App\Models\VideoDetail;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\AnalyticsExport;
use Misd\PhoneNumber\PhoneNumberUtil;

class ViewAnalyticsController extends Controller
{
    public function dashboard(Request $request)
    {
        $user = auth()->user();
        
        if (RateLimiter::tooManyAttempts("analytics-dashboard-{$user->id}", 60)) {
            return response()->json([
                'message' => 'Too many requests. Please try again later.',
                'retry_after' => RateLimiter::availableIn("analytics-dashboard-{$user->id}")
            ], 429);
        }
        
        RateLimiter::hit("analytics-dashboard-{$user->id}");
        
        $period = $request->get('period', '30');
        $videoId = $request->get('video_id');
        
        // Preparar dados para os filtros
        $countries = $this->getAvailableCountries();
        $referrers = $this->getAvailableReferrers();
        $campaigns = $this->getAvailableCampaigns();
        $devices = $this->getAvailableDevices();

        $cacheKey = $this->buildCacheKey($request->all());
        
        $analytics = Cache::remember($cacheKey, now()->addHours(1), function () use ($request, $user, $period) {
            $query = $this->buildAnalyticsQuery($request, $user);
            
            return [
                'total_views' => $this->getTotalViews($query->clone()),
                'unique_views' => $this->getUniqueViews($query->clone()),
                'views_by_day' => $this->getViewsByDay($query->clone()),
                'device_breakdown' => $this->getDeviceBreakdown($query->clone()),
                'browser_stats' => $this->getBrowserStats($query->clone()),
                'os_stats' => $this->getOsStats($query->clone()),
                'top_referrers' => $this->getTopReferrers($query->clone()),
                'peak_hours' => $this->getPeakHours($query->clone()),
                'campaign_stats' => $this->getCampaignStats($query->clone()),
                'period_comparison' => $this->getPeriodComparison($query->clone(), $period),
                'hourly_breakdown' => $this->getHourlyBreakdown($query->clone()),
                'geo_stats' => $this->getGeoStats($query->clone())
            ];
        });

        $videos = VideoDetail::where('user_id', $user->id)->get();

        return view('analytics.dashboard', compact(
            'analytics', 
            'videos', 
            'period', 
            'videoId',
            'countries',
            'referrers',
            'campaigns',
            'devices'
        ));
    }

    private function buildAnalyticsQuery(Request $request, $user)
    {
        $query = ViewStatistic::query()
            ->where('user_id', $user->id);

        // Filtro de período padrão ou datas específicas
        if ($request->filled(['start_date', 'end_date'])) {
            $query->whereBetween('created_at', [
                Carbon::parse($request->start_date)->startOfDay(),
                Carbon::parse($request->end_date)->endOfDay()
            ]);
        } else {
            $query->where('created_at', '>=', now()->subDays($request->get('period', 30)));
        }

        // Filtros avançados
        if ($request->filled('video_id')) {
            $query->where('template_id', $request->video_id);
        }

        if ($request->filled('device_type')) {
            $query->where('device_type', $request->device_type);
        }

        if ($request->filled('country')) {
            $query->where('country', $request->country);
        }

        if ($request->filled('referrer')) {
            $query->where('referrer_domain', $request->referrer);
        }

        if ($request->filled('campaign')) {
            $query->where('utm_campaign', $request->campaign);
        }

        return $query;
    }

    private function buildCacheKey(array $params)
    {
        $userId = auth()->id();
        return "analytics_{$userId}_" . md5(json_encode($params));
    }

    private function getAvailableCountries()
    {
        $userId = auth()->id();
        return Cache::remember("available_countries_{$userId}", now()->addDay(), function () use ($userId) {
            return ViewStatistic::where('user_id', $userId)
                ->distinct()
                ->whereNotNull('country')
                ->pluck('country')
                ->sort()
                ->mapWithKeys(function ($code) {
                    return [$code => $this->getCountryName($code)];
                });
        });
    }

    private function getCountryName($countryCode)
    {
        if ($countryCode === 'XX') {
            return 'Desconhecido';
        }

        try {
            return \Locale::getDisplayRegion("-" . strtoupper($countryCode), 'pt') ?: $countryCode;
        } catch (\Exception $e) {
            Log::error("Erro ao obter nome do país: " . $e->getMessage());
            return $countryCode;
        }
    }

    private function getAvailableReferrers()
    {
        $userId = auth()->id();
        return Cache::remember("available_referrers_{$userId}", now()->addHours(12), function () use ($userId) {
            return ViewStatistic::where('user_id', $userId)
                ->distinct()
                ->pluck('referrer_domain')
                ->sort();
        });
    }

    private function getAvailableCampaigns()
    {
        $userId = auth()->id();
        return Cache::remember("available_campaigns_{$userId}", now()->addHours(12), function () use ($userId) {
            return ViewStatistic::where('user_id', $userId)
                ->distinct()
                ->whereNotNull('utm_campaign')
                ->pluck('utm_campaign')
                ->sort();
        });
    }

    private function getAvailableDevices()
    {
        $userId = auth()->id();
        return Cache::remember("available_devices_{$userId}", now()->addHours(12), function () use ($userId) {
            return ViewStatistic::where('user_id', $userId)
                ->distinct()
                ->whereNotNull('device_type')
                ->pluck('device_type')
                ->sort()
                ->values()
                ->all();
        });
    }

    private function getHourlyBreakdown($query)
    {
        return $query->select(
            DB::raw('HOUR(created_at) as hour'),
            DB::raw('COUNT(*) as total'),
            DB::raw('SUM(CASE WHEN is_unique = 1 THEN 1 ELSE 0 END) as unique_views')
        )
        ->groupBy('hour')
        ->orderBy('hour')
        ->get()
        ->mapWithKeys(function ($item) {
            return [
                sprintf('%02d:00', $item->hour) => [
                    'total' => $item->total,
                    'unique' => $item->unique_views
                ]
            ];
        });
    }

    private function getGeoStats($query)
    {
        $stats = $query->select(
            'country',
            DB::raw('COUNT(*) as total'),
            DB::raw('SUM(CASE WHEN is_unique = 1 THEN 1 ELSE 0 END) as unique_views')
        )
        ->whereNotNull('country')
        ->where('country', '!=', '')
        ->groupBy('country')
        ->orderByDesc('total')
        ->limit(10)
        ->get()
        ->map(function ($item) {
            $countryCode = strtoupper($item->country);
            $country = $this->getCountryName($countryCode);
            
            Log::info("País detectado: {$country} ({$countryCode})");
            
            return [
                'country' => $country,
                'country_code' => $countryCode,
                'total' => $item->total,
                'unique' => $item->unique_views
            ];
        });

        Log::info("Total de países encontrados: " . count($stats));
        return $stats;
    }

    private function getDeviceBreakdown($query)
    {
        $results = $query->select('device_type', DB::raw('COUNT(*) as count'))
            ->whereNotNull('device_type')
            ->where('device_type', '!=', '')  // Ignora valores vazios
            ->groupBy('device_type')
            ->orderByDesc('count')
            ->get();

        // Se não houver dados, retorna um array com valores zerados
        if ($results->isEmpty()) {
            return [
                'desktop' => 0,
                'mobile' => 0,
                'tablet' => 0
            ];
        }

        // Mapeia os resultados para o formato esperado
        $deviceCounts = $results->mapWithKeys(function ($item) {
            return [$item->device_type => $item->count];
        })->all();

        // Garante que todos os tipos de dispositivo estejam presentes
        $defaultDevices = [
            'desktop' => 0,
            'mobile' => 0,
            'tablet' => 0
        ];

        return array_merge($defaultDevices, $deviceCounts);
    }

    public function export(Request $request)
    {
        $user = auth()->user();
        
        if (RateLimiter::tooManyAttempts("analytics-export-{$user->id}", 10)) {
            return response()->json([
                'message' => 'Too many export requests. Please try again later.',
                'retry_after' => RateLimiter::availableIn("analytics-export-{$user->id}")
            ], 429);
        }
        
        RateLimiter::hit("analytics-export-{$user->id}");

        $period = $request->get('period', '30');
        $videoId = $request->get('video_id');
        $startDate = now()->subDays($period);

        $query = ViewStatistic::query()
            ->when($videoId, function ($q) use ($videoId) {
                return $q->where('template_id', $videoId);
            })
            ->where('user_id', $user->id)
            ->where('created_at', '>=', $startDate)
            ->orderBy('created_at', 'desc');

        return Excel::download(
            new AnalyticsExport($query),
            "analytics-report-{$period}days.xlsx"
        );
    }

    private function getTotalViews($query)
    {
        return $query->count();
    }

    private function getUniqueViews($query)
    {
        return $query->where('is_unique', true)->count();
    }

    private function getViewsByDay($query)
    {
        return $query->select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('COUNT(*) as total'),
            DB::raw('SUM(CASE WHEN is_unique = 1 THEN 1 ELSE 0 END) as unique_views')
        )
        ->groupBy('date')
        ->orderBy('date')
        ->get()
        ->map(function ($item) {
            return [
                'date' => $item->date,
                'total' => $item->total,
                'unique' => $item->unique_views
            ];
        });
    }

    private function getBrowserStats($query)
    {
        return $query->select('browser', DB::raw('COUNT(*) as count'))
            ->groupBy('browser')
            ->orderByDesc('count')
            ->limit(5)
            ->get();
    }

    private function getOsStats($query)
    {
        return $query->select('os', DB::raw('COUNT(*) as count'))
            ->groupBy('os')
            ->orderByDesc('count')
            ->limit(5)
            ->get();
    }

    private function getTopReferrers($query)
    {
        $userId = auth()->id();
        $cacheKey = "top_referrers_{$userId}_" . md5($query->toSql());
        
        return Cache::remember($cacheKey, now()->addHours(1), function () use ($query) {
            return $query->whereNotNull('referrer_domain')
                ->select('referrer_domain', DB::raw('COUNT(*) as count'))
                ->groupBy('referrer_domain')
                ->orderByDesc('count')
                ->paginate(10);
        });
    }

    private function getPeakHours($query)
    {
        return $query->select(DB::raw('HOUR(created_at) as hour'), DB::raw('COUNT(*) as count'))
            ->groupBy('hour')
            ->orderBy('hour')
            ->get()
            ->mapWithKeys(function ($item) {
                return [sprintf('%02d:00', $item->hour) => $item->count];
            });
    }

    private function getCampaignStats($query)
    {
        $userId = auth()->id();
        $cacheKey = "campaign_stats_{$userId}_" . md5($query->toSql());
        
        return Cache::remember($cacheKey, now()->addHours(1), function () use ($query) {
            return [
                'sources' => $query->whereNotNull('utm_source')
                    ->select('utm_source', DB::raw('COUNT(*) as count'))
                    ->groupBy('utm_source')
                    ->orderByDesc('count')
                    ->limit(5)
                    ->get(),
                'mediums' => $query->whereNotNull('utm_medium')
                    ->select('utm_medium', DB::raw('COUNT(*) as count'))
                    ->groupBy('utm_medium')
                    ->orderByDesc('count')
                    ->limit(5)
                    ->get(),
                'campaigns' => $query->whereNotNull('utm_campaign')
                    ->select('utm_campaign', DB::raw('COUNT(*) as count'))
                    ->groupBy('utm_campaign')
                    ->orderByDesc('count')
                    ->limit(5)
                    ->get()
            ];
        });
    }

    private function getPeriodComparison($query, $previousPeriod)
    {
        $userId = auth()->id();
        $cacheKey = "period_comparison_{$userId}_{$previousPeriod}_" . md5($query->toSql());
        
        return Cache::remember($cacheKey, now()->addHours(1), function () use ($query, $previousPeriod) {
            $currentPeriodStats = $query->count();
            
            $previousStartDate = now()->subDays($previousPeriod * 2);
            $previousEndDate = now()->subDays($previousPeriod);
            
            // Cria uma nova query para o período anterior
            $previousQuery = $query->clone()->whereBetween('created_at', [$previousStartDate, $previousEndDate]);
            $previousPeriodStats = $previousQuery->count();
            
            $percentageChange = $previousPeriodStats > 0 
                ? (($currentPeriodStats - $previousPeriodStats) / $previousPeriodStats) * 100 
                : 100;
            
            return [
                'current_period' => $currentPeriodStats,
                'previous_period' => $previousPeriodStats,
                'percentage_change' => round($percentageChange, 2)
            ];
        });
    }
}
