<?php

namespace App\Http\Controllers;

use App\Models\BroadCastComment;
use App\Models\CommentFrequency;
use App\Models\VideoDetail;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function store(Request $request, $uuid)
    {
        $request->validate([
            'minSec' => 'required',
            'maxSec' => 'required',
            'commentarr' => 'required'
        ]);

        $videoDetails = VideoDetail::where('uuid', $uuid)->first();
        if (!$videoDetails) {
            return response()->json([
                'message' => "Video not found"
            ]);
        }

        $commmentFrequest = CommentFrequency::updateOrCreate([
            'video_details_id' => $videoDetails->id
        ], [
            'min_Sec' => $request->minSec,
            'max_Sec' => $request->maxSec
        ]);

        $broadCastComment = BroadCastComment::where('video_details_id', $videoDetails->id)->delete();

        foreach ($request->commentarr as $key => $comment) {
            $newComment = BroadCastComment::create([
                'video_details_id' => $videoDetails->id,
                'comment' => $comment
            ]);
        }
        return response()->json(['message' => 'Comment created successfully']);
    }


    public function comments($uuid)
    {
        $videoDetails = VideoDetail::where('uuid', $uuid)->first();
        if (!$videoDetails) {
            return response()->json([
                'message' => "Video not found"
            ]);
        }
        $broadCastComment = BroadCastComment::where('video_details_id', $videoDetails->id)->get();
        return response()->json(['comments' => $broadCastComment]);
    }
}
