<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Subscription;
use App\Models\VideoDetail;
use Illuminate\Http\Request;


class UserController extends Controller
{
    public function users()
{

 $users = User::whereHas('roles', function ($q) {
        $q->where('name', 'user');
    })->whereHas('subscriptions')
    ->paginate(10);

    return view("admin.users", compact('users'));
}

    
     public function users_edit($uuid)
    {
      $user = User::where('uuid', $uuid)->first();
        return view("admin.edit-user", compact('user'));
    }
    
    
    public function users_update(Request $request, $uuid)
{
    $user = User::where('uuid', $uuid)->first();

    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
    ]);

    $user->name = $request->name;
    $user->email = $request->email;
    $user->save();

    return redirect()->route('admin.users', $user->uuid)->with('success', __('dashboard.user_updated_successfully'));
}

public function users_delete($uuid)
{
    $user = User::where('uuid', $uuid)->first();

    if ($user) {
        
        Subscription::where('user_id', $user->id)->delete();
              $videoDetails = VideoDetail::where('user_id', $user->id)->get();

        foreach ($videoDetails as $videoDetail) {
            $videoDetail->videoThumbnail()->delete();
            $videoDetail->videoComment()->delete();
            $videoDetail->delete();
        }
        $user->delete();

       return redirect()->route('admin.users')->with('success', __('dashboard.user_and_subscriptions_deleted_successfully'));
    } else {
       return redirect()->route('admin.users')->with('error', __('dashboard.user_not_found'));
    }
}


}
